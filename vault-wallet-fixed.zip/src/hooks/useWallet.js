import { useState, useEffect, useCallback } from 'react'
import { ethers } from 'ethers'

export function useWallet() {
  const [account, setAccount] = useState(null)
  const [balance, setBalance] = useState(null)
  const [network, setNetwork] = useState(null)
  const [provider, setProvider] = useState(null)
  const [status, setStatus] = useState('idle') // idle | connecting | connected | error
  const [error, setError] = useState(null)

  const fetchBalance = useCallback(async (address, prov) => {
    try {
      const bal = await prov.getBalance(address)
      setBalance(ethers.formatEther(bal))
    } catch (e) {
      console.error('Balance fetch failed:', e)
    }
  }, [])

  const fetchNetwork = useCallback(async (prov) => {
    try {
      const net = await prov.getNetwork()
      setNetwork(net)
    } catch (e) {
      console.error('Network fetch failed:', e)
    }
  }, [])

  const connect = useCallback(async () => {
    setError(null)
    if (!window.ethereum) {
      setError('MetaMask not detected. Please install MetaMask to continue.')
      setStatus('error')
      return
    }
    try {
      setStatus('connecting')
      const prov = new ethers.BrowserProvider(window.ethereum)
      const accounts = await prov.send('eth_requestAccounts', [])
      if (accounts.length === 0) throw new Error('No accounts found')
      setProvider(prov)
      setAccount(accounts[0])
      setStatus('connected')
      await fetchBalance(accounts[0], prov)
      await fetchNetwork(prov)
    } catch (e) {
      if (e.code === 4001) {
        setError('Connection rejected. Please approve the MetaMask request.')
      } else {
        setError(e.message || 'Connection failed')
      }
      setStatus('error')
    }
  }, [fetchBalance, fetchNetwork])

  const disconnect = useCallback(() => {
    setAccount(null)
    setBalance(null)
    setNetwork(null)
    setProvider(null)
    setStatus('idle')
    setError(null)
  }, [])

  const refreshBalance = useCallback(async () => {
    if (account && provider) {
      await fetchBalance(account, provider)
    }
  }, [account, provider, fetchBalance])

  // Listen for account/network changes
  useEffect(() => {
    if (!window.ethereum) return

    const handleAccountsChanged = async (accounts) => {
      if (accounts.length === 0) {
        disconnect()
      } else {
        setAccount(accounts[0])
        if (provider) await fetchBalance(accounts[0], provider)
      }
    }

    const handleChainChanged = () => {
      window.location.reload()
    }

    window.ethereum.on('accountsChanged', handleAccountsChanged)
    window.ethereum.on('chainChanged', handleChainChanged)

    return () => {
      window.ethereum.removeListener('accountsChanged', handleAccountsChanged)
      window.ethereum.removeListener('chainChanged', handleChainChanged)
    }
  }, [provider, disconnect, fetchBalance])

  // Check if already connected on page load
  useEffect(() => {
    const checkConnection = async () => {
      if (!window.ethereum) return
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' })
        if (accounts.length > 0) {
          const prov = new ethers.BrowserProvider(window.ethereum)
          setProvider(prov)
          setAccount(accounts[0])
          setStatus('connected')
          await fetchBalance(accounts[0], prov)
          await fetchNetwork(prov)
        }
      } catch (e) {
        console.error('Auto-connect check failed:', e)
      }
    }
    checkConnection()
  }, [fetchBalance, fetchNetwork])

  return { account, balance, network, status, error, connect, disconnect, refreshBalance }
}
