import { getNetworkName } from '../utils/helpers'

export default function StatsRow({ account, balance, network }) {
  const chainIdStr = network ? network.chainId.toString() : '—'

  const stats = [
    {
      label: 'Network',
      value: getNetworkName(network),
      icon: '⬡',
      color: '#7c3aed',
      delay: '0.1s',
    },
    {
      label: 'Chain ID',
      value: network ? `#${chainIdStr}` : '—',
      icon: '⛓',
      color: '#06b6d4',
      delay: '0.2s',
    },
    {
      label: 'Status',
      value: 'Active',
      icon: '◉',
      color: '#10b981',
      delay: '0.3s',
    },
  ]

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '1rem',
    }}>
      {stats.map((stat) => (
        <div key={stat.label} style={{
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid var(--border)',
          borderRadius: '16px',
          padding: '1.25rem 1rem',
          animation: `slide-up 0.5s ease ${stat.delay} forwards`,
          opacity: 0,
          transition: 'border-color 0.2s',
        }}
          onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'}
          onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
        >
          <div style={{
            display: 'flex', alignItems: 'center', gap: '0.4rem',
            marginBottom: '0.65rem',
          }}>
            <span style={{ color: stat.color, fontSize: '0.85rem' }}>{stat.icon}</span>
            <span style={{
              fontSize: '0.58rem',
              color: 'var(--text-muted)',
              fontFamily: 'var(--font-mono)',
              letterSpacing: '0.18em',
            }}>
              {stat.label.toUpperCase()}
            </span>
          </div>
          <div style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '0.88rem',
            fontWeight: 700,
            color: 'var(--text)',
            letterSpacing: '0.02em',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {stat.value}
          </div>
        </div>
      ))}
    </div>
  )
}
