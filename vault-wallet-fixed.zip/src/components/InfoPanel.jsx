export default function InfoPanel() {
  const tips = [
    {
      icon: '🔐',
      title: 'Self-custody',
      desc: 'Your wallet keys never leave your browser. VAULT never has access to your funds or private keys.',
    },
    {
      icon: '⚡',
      title: 'Live data',
      desc: 'Balance and network info is fetched directly from the blockchain via your MetaMask provider.',
    },
    {
      icon: '🌐',
      title: 'Multi-chain',
      desc: 'Switch networks inside MetaMask — VAULT automatically updates to reflect your active chain.',
    },
  ]

  return (
    <div style={{
      background: 'rgba(255,255,255,0.02)',
      border: '1px solid var(--border)',
      borderRadius: '20px',
      padding: '1.75rem',
      animation: 'slide-up 0.5s ease 0.4s forwards',
      opacity: 0,
    }}>
      <div style={{
        fontSize: '0.6rem',
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-mono)',
        letterSpacing: '0.22em',
        marginBottom: '1.5rem',
      }}>
        ABOUT VAULT
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.4rem' }}>
        {tips.map((tip) => (
          <div key={tip.title} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
            <div style={{
              width: '38px', height: '38px',
              borderRadius: '11px',
              background: 'rgba(124,58,237,0.12)',
              border: '1px solid rgba(124,58,237,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1rem',
              flexShrink: 0,
            }}>
              {tip.icon}
            </div>
            <div>
              <div style={{
                fontSize: '0.88rem',
                fontWeight: 700,
                color: 'var(--text)',
                marginBottom: '0.25rem',
              }}>
                {tip.title}
              </div>
              <div style={{
                fontSize: '0.78rem',
                color: 'var(--text-muted)',
                lineHeight: 1.6,
              }}>
                {tip.desc}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
