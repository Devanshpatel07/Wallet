import { useState } from 'react'

export default function ConnectScreen({ onConnect, status, error }) {
  const [hovered, setHovered] = useState(false)
  const isConnecting = status === 'connecting'

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      padding: '2rem',
      position: 'relative',
      zIndex: 1,
    }}>

      {/* Logo */}
      <div style={{
        width: '88px', height: '88px',
        marginBottom: '2rem',
        position: 'relative',
        animation: 'float 5s ease-in-out infinite',
      }}>
        <div style={{
          width: '88px', height: '88px',
          borderRadius: '26px',
          background: 'linear-gradient(135deg, #7c3aed, #06b6d4)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '40px',
          boxShadow: '0 0 60px rgba(124,58,237,0.5), 0 0 120px rgba(124,58,237,0.2)',
        }}>◈</div>
        <div style={{
          position: 'absolute', inset: '-10px',
          borderRadius: '36px',
          border: '1px solid rgba(124,58,237,0.3)',
          animation: 'spin-slow 8s linear infinite',
        }} />
        <div style={{
          position: 'absolute', inset: '-20px',
          borderRadius: '46px',
          border: '1px solid rgba(6,182,212,0.15)',
          animation: 'spin-slow 14s linear infinite reverse',
        }} />
      </div>

      {/* Title */}
      <h1 style={{
        fontFamily: 'var(--font-display)',
        fontSize: 'clamp(2.8rem, 6vw, 4.5rem)',
        fontWeight: 800,
        letterSpacing: '-0.03em',
        background: 'linear-gradient(135deg, #f0f0ff 30%, rgba(124,58,237,0.9))',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
        backgroundClip: 'text',
        marginBottom: '0.5rem',
        textAlign: 'center',
        animation: 'slide-up 0.5s ease forwards',
      }}>
        VAULT
      </h1>

      <p style={{
        fontFamily: 'var(--font-mono)',
        fontSize: '0.75rem',
        color: 'var(--text-muted)',
        letterSpacing: '0.3em',
        textTransform: 'uppercase',
        marginBottom: '3rem',
        textAlign: 'center',
        animation: 'slide-up 0.5s ease 0.1s forwards',
        opacity: 0,
      }}>
        Web3 Wallet Interface
      </p>

      {/* Feature pills */}
      <div style={{
        display: 'flex', gap: '0.75rem', flexWrap: 'wrap',
        justifyContent: 'center', marginBottom: '3rem',
      }}>
        {['Non-custodial', 'MetaMask Ready', 'Multi-chain'].map((feat, i) => (
          <span key={feat} style={{
            padding: '0.4rem 1rem',
            borderRadius: '100px',
            border: '1px solid var(--border)',
            background: 'rgba(255,255,255,0.03)',
            fontSize: '0.72rem',
            fontFamily: 'var(--font-mono)',
            color: 'var(--text-muted)',
            letterSpacing: '0.08em',
            animation: `slide-up 0.5s ease ${0.2 + i * 0.1}s forwards`,
            opacity: 0,
          }}>
            {feat}
          </span>
        ))}
      </div>

      {/* Connect Button */}
      <button
        onClick={onConnect}
        disabled={isConnecting}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          position: 'relative',
          padding: '1.1rem 2.75rem',
          borderRadius: '16px',
          border: 'none',
          background: isConnecting
            ? 'rgba(124,58,237,0.4)'
            : hovered
            ? 'linear-gradient(135deg, #8b5cf6, #0ea5e9)'
            : 'linear-gradient(135deg, #7c3aed, #06b6d4)',
          color: '#fff',
          fontSize: '1rem',
          fontWeight: 700,
          fontFamily: 'var(--font-display)',
          letterSpacing: '0.05em',
          cursor: isConnecting ? 'wait' : 'pointer',
          boxShadow: hovered
            ? '0 0 60px rgba(124,58,237,0.7), 0 0 120px rgba(6,182,212,0.3)'
            : '0 0 30px rgba(124,58,237,0.4)',
          transition: 'all 0.3s ease',
          transform: hovered && !isConnecting ? 'translateY(-3px) scale(1.03)' : 'none',
          display: 'flex', alignItems: 'center', gap: '0.75rem',
          animation: 'slide-up 0.5s ease 0.5s forwards',
          opacity: 0,
          minWidth: '240px',
          justifyContent: 'center',
          overflow: 'hidden',
        }}
      >
        {/* Shimmer overlay */}
        {hovered && !isConnecting && (
          <div style={{
            position: 'absolute', top: 0, left: '-100%',
            width: '60%', height: '100%',
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)',
            animation: 'shimmer 1s ease',
          }} />
        )}

        {isConnecting ? (
          <>
            <Spinner />
            Connecting...
          </>
        ) : (
          <>
            <span style={{ fontSize: '1.3rem' }}>🦊</span>
            Connect MetaMask
          </>
        )}
      </button>

      {/* Error message */}
      {error && (
        <div style={{
          marginTop: '1.75rem',
          padding: '1rem 1.25rem',
          borderRadius: '14px',
          background: 'rgba(239,68,68,0.1)',
          border: '1px solid rgba(239,68,68,0.3)',
          color: '#fca5a5',
          fontSize: '0.85rem',
          fontFamily: 'var(--font-mono)',
          maxWidth: '380px',
          textAlign: 'center',
          animation: 'fade-in 0.3s ease',
          lineHeight: 1.6,
        }}>
          <div style={{ marginBottom: error.includes('MetaMask') ? '0.6rem' : 0 }}>
            ⚠ {error}
          </div>
          {error.includes('MetaMask') && (
            <a
              href="https://metamask.io/download/"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                color: 'var(--accent2)',
                textDecoration: 'none',
                fontWeight: 700,
                fontSize: '0.8rem',
              }}
            >
              Download MetaMask →
            </a>
          )}
        </div>
      )}

      <p style={{
        position: 'fixed', bottom: '2rem',
        fontFamily: 'var(--font-mono)',
        fontSize: '0.62rem',
        color: 'var(--text-dim)',
        letterSpacing: '0.15em',
        textAlign: 'center',
      }}>
        YOUR KEYS · YOUR CRYPTO · YOUR CONTROL
      </p>
    </div>
  )
}

function Spinner() {
  return (
    <div style={{
      width: '16px', height: '16px', flexShrink: 0,
      border: '2px solid rgba(255,255,255,0.3)',
      borderTopColor: '#fff',
      borderRadius: '50%',
      animation: 'spin-slow 0.7s linear infinite',
    }} />
  )
}
