import { useState } from 'react'
import { shortenAddress, formatBalance, getNetworkName, getNetworkColor, copyToClipboard, getExplorerUrl } from '../utils/helpers'

export default function WalletCard({ account, balance, network, onRefresh, onDisconnect }) {
  const [copied, setCopied] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  const handleCopy = async () => {
    try {
      await copyToClipboard(account)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // fallback
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)
    await onRefresh()
    setTimeout(() => setRefreshing(false), 800)
  }

  const networkColor = getNetworkColor(network)
  const networkName = getNetworkName(network)
  const explorerUrl = getExplorerUrl(account, network)

  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(124,58,237,0.12) 0%, rgba(6,182,212,0.05) 100%)',
      border: '1px solid rgba(124,58,237,0.25)',
      borderRadius: '24px',
      padding: '2rem',
      position: 'relative',
      overflow: 'hidden',
      animation: 'slide-up 0.5s ease forwards',
    }}>
      {/* Corner glow */}
      <div style={{
        position: 'absolute', top: 0, right: 0,
        width: '200px', height: '200px',
        background: 'radial-gradient(circle at top right, rgba(124,58,237,0.2), transparent 70%)',
        pointerEvents: 'none',
      }} />

      {/* Bottom left glow */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0,
        width: '150px', height: '150px',
        background: 'radial-gradient(circle at bottom left, rgba(6,182,212,0.1), transparent 70%)',
        pointerEvents: 'none',
      }} />

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
          <div style={{
            width: '46px', height: '46px',
            borderRadius: '14px',
            background: `linear-gradient(135deg, ${networkColor}cc, #7c3aed)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.3rem',
            boxShadow: `0 0 20px ${networkColor}55`,
            flexShrink: 0,
          }}>
            ◎
          </div>
          <div>
            <div style={{
              fontSize: '0.62rem',
              color: 'var(--text-muted)',
              fontFamily: 'var(--font-mono)',
              letterSpacing: '0.18em',
              marginBottom: '3px',
            }}>
              CONNECTED WALLET
            </div>
            <div style={{
              fontSize: '1rem',
              fontWeight: 700,
              fontFamily: 'var(--font-mono)',
              color: 'var(--text)',
              letterSpacing: '0.03em',
            }}>
              {shortenAddress(account)}
            </div>
          </div>
        </div>

        {/* Network badge */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.5rem',
          padding: '0.45rem 0.9rem',
          borderRadius: '100px',
          background: `${networkColor}15`,
          border: `1px solid ${networkColor}40`,
          flexShrink: 0,
        }}>
          <div style={{
            width: '7px', height: '7px',
            borderRadius: '50%',
            background: networkColor,
            boxShadow: `0 0 8px ${networkColor}`,
            animation: 'pulse-glow 2s ease infinite',
          }} />
          <span style={{
            fontSize: '0.72rem',
            fontFamily: 'var(--font-mono)',
            color: networkColor,
            fontWeight: 700,
            letterSpacing: '0.06em',
          }}>
            {networkName}
          </span>
        </div>
      </div>

      {/* Balance */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{
          fontSize: '0.62rem',
          color: 'var(--text-muted)',
          fontFamily: 'var(--font-mono)',
          letterSpacing: '0.22em',
          marginBottom: '0.5rem',
        }}>
          BALANCE
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.6rem' }}>
          <span style={{
            fontSize: 'clamp(2.2rem, 6vw, 3.2rem)',
            fontWeight: 800,
            fontFamily: 'var(--font-display)',
            background: 'linear-gradient(135deg, #f0f0ff 40%, rgba(124,58,237,0.9))',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            letterSpacing: '-0.03em',
            lineHeight: 1,
          }}>
            {formatBalance(balance)}
          </span>
          <span style={{
            fontSize: '1.1rem',
            color: 'var(--text-muted)',
            fontFamily: 'var(--font-mono)',
            fontWeight: 700,
            paddingBottom: '4px',
          }}>
            ETH
          </span>
        </div>
      </div>

      {/* Address row */}
      <div
        onClick={handleCopy}
        style={{
          background: 'rgba(0,0,0,0.3)',
          border: '1px solid var(--border)',
          borderRadius: '12px',
          padding: '0.8rem 1rem',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: '1.25rem',
          cursor: 'pointer',
          transition: 'border-color 0.2s',
        }}
        onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'}
        onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
      >
        <span style={{
          fontFamily: 'var(--font-mono)',
          fontSize: '0.7rem',
          color: 'var(--text-muted)',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
          flex: 1,
          letterSpacing: '0.03em',
        }}>
          {account}
        </span>
        <span style={{
          fontSize: '0.7rem',
          fontFamily: 'var(--font-mono)',
          color: copied ? 'var(--success)' : 'var(--accent2)',
          marginLeft: '1rem',
          flexShrink: 0,
          fontWeight: 700,
          transition: 'color 0.2s',
        }}>
          {copied ? '✓ Copied!' : 'Copy'}
        </span>
      </div>

      {/* Action buttons */}
      <div style={{ display: 'flex', gap: '0.75rem' }}>
        <ActionBtn
          onClick={handleRefresh}
          style={{ flex: 1 }}
        >
          <span style={{
            display: 'inline-block',
            animation: refreshing ? 'spin-slow 0.8s linear infinite' : 'none',
          }}>↻</span>
          Refresh
        </ActionBtn>

        <a
          href={explorerUrl}
          target="_blank"
          rel="noopener noreferrer"
          style={{
            flex: 1,
            padding: '0.75rem',
            borderRadius: '12px',
            border: '1px solid var(--border)',
            background: 'rgba(255,255,255,0.04)',
            color: 'var(--text)',
            fontFamily: 'var(--font-display)',
            fontSize: '0.85rem',
            fontWeight: 600,
            cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
            textDecoration: 'none',
            transition: 'background 0.2s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.08)'}
          onMouseLeave={e => e.currentTarget.style.background = 'rgba(255,255,255,0.04)'}
        >
          ↗ Explorer
        </a>

        <button
          onClick={onDisconnect}
          style={{
            flex: 1,
            padding: '0.75rem',
            borderRadius: '12px',
            border: '1px solid rgba(239,68,68,0.25)',
            background: 'rgba(239,68,68,0.07)',
            color: '#fca5a5',
            fontFamily: 'var(--font-display)',
            fontSize: '0.85rem',
            fontWeight: 600,
            cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
            transition: 'background 0.2s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = 'rgba(239,68,68,0.14)'}
          onMouseLeave={e => e.currentTarget.style.background = 'rgba(239,68,68,0.07)'}
        >
          ⏻ Disconnect
        </button>
      </div>
    </div>
  )
}

function ActionBtn({ onClick, children, style }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '0.75rem',
        borderRadius: '12px',
        border: '1px solid var(--border)',
        background: 'rgba(255,255,255,0.04)',
        color: 'var(--text)',
        fontFamily: 'var(--font-display)',
        fontSize: '0.85rem',
        fontWeight: 600,
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
        transition: 'background 0.2s',
        ...style,
      }}
      onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.08)'}
      onMouseLeave={e => e.currentTarget.style.background = 'rgba(255,255,255,0.04)'}
    >
      {children}
    </button>
  )
}
