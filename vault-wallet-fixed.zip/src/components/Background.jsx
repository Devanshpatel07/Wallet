export default function Background() {
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 0,
      overflow: 'hidden', pointerEvents: 'none'
    }}>
      {/* Grid lines */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `
          linear-gradient(rgba(124,58,237,0.05) 1px, transparent 1px),
          linear-gradient(90deg, rgba(124,58,237,0.05) 1px, transparent 1px)
        `,
        backgroundSize: '60px 60px',
      }} />

      {/* Top-left orb */}
      <div style={{
        position: 'absolute', top: '-20%', left: '-10%',
        width: '600px', height: '600px',
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(124,58,237,0.15) 0%, transparent 70%)',
        animation: 'float 8s ease-in-out infinite',
      }} />

      {/* Bottom-right orb */}
      <div style={{
        position: 'absolute', bottom: '-20%', right: '-10%',
        width: '500px', height: '500px',
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(6,182,212,0.12) 0%, transparent 70%)',
        animation: 'float 10s ease-in-out infinite reverse',
      }} />

      {/* Center glow */}
      <div style={{
        position: 'absolute', top: '40%', left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '800px', height: '400px',
        background: 'radial-gradient(ellipse, rgba(124,58,237,0.06) 0%, transparent 60%)',
      }} />

      {/* Scan line */}
      <div style={{
        position: 'absolute', left: 0, right: 0,
        height: '1px',
        background: 'linear-gradient(90deg, transparent, rgba(124,58,237,0.5), transparent)',
        animation: 'scan 6s linear infinite',
        opacity: 0.4,
      }} />
    </div>
  )
}
