import WalletCard from './WalletCard'
import StatsRow from './StatsRow'
import InfoPanel from './InfoPanel'

export default function Dashboard({ account, balance, network, onRefresh, onDisconnect }) {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '2rem 1.5rem 4rem',
      position: 'relative',
      zIndex: 1,
    }}>

      {/* Header */}
      <header style={{
        width: '100%',
        maxWidth: '520px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '2.5rem',
        animation: 'fade-in 0.4s ease',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div style={{
            width: '34px', height: '34px',
            borderRadius: '10px',
            background: 'linear-gradient(135deg, #7c3aed, #06b6d4)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '0.9rem',
            boxShadow: '0 0 16px rgba(124,58,237,0.4)',
          }}>◈</div>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontWeight: 800,
            fontSize: '1.15rem',
            letterSpacing: '0.12em',
          }}>VAULT</span>
        </div>

        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.5rem',
          padding: '0.38rem 0.85rem',
          borderRadius: '100px',
          background: 'rgba(16,185,129,0.1)',
          border: '1px solid rgba(16,185,129,0.25)',
        }}>
          <div style={{
            width: '7px', height: '7px',
            borderRadius: '50%',
            background: '#10b981',
            boxShadow: '0 0 8px #10b981',
            animation: 'pulse-glow 2s ease infinite',
          }} />
          <span style={{
            fontSize: '0.68rem',
            fontFamily: 'var(--font-mono)',
            color: '#10b981',
            letterSpacing: '0.12em',
            fontWeight: 700,
          }}>LIVE</span>
        </div>
      </header>

      {/* Content */}
      <main style={{
        width: '100%',
        maxWidth: '520px',
        display: 'flex',
        flexDirection: 'column',
        gap: '1.25rem',
      }}>
        <WalletCard
          account={account}
          balance={balance}
          network={network}
          onRefresh={onRefresh}
          onDisconnect={onDisconnect}
        />
        <StatsRow account={account} balance={balance} network={network} />
        <InfoPanel />
      </main>

      {/* Footer */}
      <footer style={{
        marginTop: '3rem',
        fontFamily: 'var(--font-mono)',
        fontSize: '0.6rem',
        color: 'var(--text-dim)',
        letterSpacing: '0.15em',
        textAlign: 'center',
      }}>
        BUILT WITH ETHERS.JS · REACT · VITE · NON-CUSTODIAL
      </footer>
    </div>
  )
}
