export function shortenAddress(address) {
  if (!address) return ''
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatBalance(balance) {
  if (balance === null || balance === undefined) return '—'
  const num = parseFloat(balance)
  if (num === 0) return '0.0000'
  if (num < 0.0001) return '< 0.0001'
  return num.toFixed(4)
}

export function getNetworkName(network) {
  if (!network) return 'Unknown'
  const names = {
    1n: 'Ethereum',
    5n: 'Goerli',
    11155111n: 'Sepolia',
    137n: 'Polygon',
    80001n: 'Mumbai',
    42161n: 'Arbitrum',
    10n: 'Optimism',
    56n: 'BNB Chain',
    43114n: 'Avalanche',
    8453n: 'Base',
  }
  return names[network.chainId] || `Chain ${network.chainId}`
}

export function getNetworkColor(network) {
  if (!network) return '#888'
  const colors = {
    1n: '#627EEA',
    5n: '#627EEA',
    11155111n: '#627EEA',
    137n: '#8247E5',
    42161n: '#28A0F0',
    10n: '#FF0420',
    56n: '#F0B90B',
    43114n: '#E84142',
    8453n: '#0052FF',
  }
  return colors[network.chainId] || '#06b6d4'
}

export function copyToClipboard(text) {
  return navigator.clipboard.writeText(text)
}

export function getExplorerUrl(address, network) {
  if (!network || !address) return `https://etherscan.io/address/${address}`
  const explorers = {
    1n: `https://etherscan.io/address/${address}`,
    11155111n: `https://sepolia.etherscan.io/address/${address}`,
    137n: `https://polygonscan.com/address/${address}`,
    42161n: `https://arbiscan.io/address/${address}`,
    10n: `https://optimistic.etherscan.io/address/${address}`,
    56n: `https://bscscan.com/address/${address}`,
    43114n: `https://snowtrace.io/address/${address}`,
    8453n: `https://basescan.org/address/${address}`,
  }
  return explorers[network.chainId] || `https://etherscan.io/address/${address}`
}
