import { useWallet } from './hooks/useWallet'
import Background from './components/Background'
import ConnectScreen from './components/ConnectScreen'
import Dashboard from './components/Dashboard'

export default function App() {
  const { account, balance, network, status, error, connect, disconnect, refreshBalance } = useWallet()

  const isConnected = status === 'connected' && account

  return (
    <>
      <Background />
      {isConnected ? (
        <Dashboard
          account={account}
          balance={balance}
          network={network}
          onRefresh={refreshBalance}
          onDisconnect={disconnect}
        />
      ) : (
        <ConnectScreen
          onConnect={connect}
          status={status}
          error={error}
        />
      )}
    </>
  )
}
